<?php

defined('PLUGIN_VERSION') or define('PLUGIN_VERSION', '1.0.3');
defined('METADATA_SOURCE_PARAM') or define('METADATA_SOURCE_PARAM', 'source');
defined('METADATA_INVOICE_PARAM') or define('METADATA_INVOICE_PARAM', 'invoiceid');
defined('METADATA_CLIENT_PARAM') or define('METADATA_CLIENT_PARAM', 'clientid');
defined('METADATA_SOURCE_VALUE') or define('METADATA_SOURCE_VALUE', 'oscommerce');
defined('SIGNATURE_HEADER') or define('SIGNATURE_HEADER', 'x-cc-webhook-signature');
